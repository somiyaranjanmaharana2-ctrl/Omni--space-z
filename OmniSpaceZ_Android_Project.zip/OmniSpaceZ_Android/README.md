# Omni Space Z — Android Studio project

This is a native Android shell around the mobile-first Omni Space Z website. It enables JavaScript and DOM storage in its WebView so the page's interactive buttons and sound effects can run inside the app. The story button was also adjusted to pass its button element explicitly instead of relying on the browser's global `event`.

## Build an APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose **Open**, then select the `OmniSpaceZ_Android` folder.
4. Wait for Gradle sync to finish. Use JDK 17 if Android Studio asks.
5. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Android Studio will show the APK location. Transfer it to your phone and install it. Android may ask you to allow installation from that source.

## Included
- Mobile-first dark space interface and bottom navigation
- Optional Web Audio sound effects
- Random fact button, story expand/collapse, planet preview selectors
- Orion demo chat with local sample answers
- Back-button navigation and dark system bars

## Limitations
This is an Android Studio source project, not a prebuilt APK. Building an APK requires Android SDK/Gradle tools on a computer. Orion is still an offline demo; a real AI assistant needs a secure backend. The planet previews are not full 3D models and the article list is not a live news feed.
